
	include "AMD"
	include "Intel"
--	include "NVIDIA"
	